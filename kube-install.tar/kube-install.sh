#!/bin/bash

curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo apt-get update
sudo apt-get install -y software-properties-common
sudo add-apt-repository    "deb [arch=amd64] https://download.docker.com/linux/ubuntu 
   $(lsb_release -cs) 
   stable"
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -
cat << EOF | sudo tee /etc/apt/sources.list.d/kubernetes.list
deb https://apt.kubernetes.io/ kubernetes-xenial main
EOF
sudo apt-get update
sudo apt-get install -y docker-ce kubelet kubeadm kubectl
sudo apt-mark hold docker-ce kubelet kubeadm kubectl

sudo swapoff -a

LOG="/local/kube_start.log"
PROJ_DIR="$(ls /proj/ | tail -1)"
KUBE_DIR="/proj/${PROJ_DIR}/kube-config"
KUBE_JOIN=${KUBE_DIR}/kube-join.sh
PROJ_DIR="$(ls /proj/ | tail -1)"

echo "executing kube-start" > ${LOG}

sudo rm -f ${KUBE_JOIN}
HOSTNAME="$(hostname)"
#echo ${HOSTNAME}

if [[ ${HOSTNAME} =~ "kubernetes00" ]]; then
    echo "I am the master" >> ${LOG}
    mkdir ${KUBE_DIR}
    echo "Made proj directory" >> ${LOG}
    sudo echo "#!/bin/bash" > ${KUBE_JOIN}
    echo "Created kube join file" >> ${LOG}
    sudo chmod +x ${KUBE_JOIN}

    export KUBECONFIG=/local/kubeconfig
    echo "Exported KUBECONFIG" >> ${LOG}
    JOIN_STRING="$(sudo kubeadm init --pod-network-cidr=10.244.0.0/16 | tail -2)"
    echo "Finished kubeadm init" >> ${LOG}
    sudo cp -i /etc/kubernetes/admin.conf /local/kubeconfig
    sudo chmod 777 /local/kubeconfig
    #sudo chown $(id -u):$(id -g) /local/kubeconfig
    kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
    echo "applied flannel" >> ${LOG}
    sudo echo ${JOIN_STRING} > ${KUBE_JOIN}
else
    echo "I am a worker" >> ${LOG}
    until [ -f ${KUBE_JOIN} ]
    do
    echo "Waiting for join command" >> ${LOG}
        sleep 5
    done
    echo "Joining" >> ${LOG}
    sudo ${KUBE_JOIN}
    echo "Joined" >> ${LOG}
fi

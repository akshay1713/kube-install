#!/bin/bash
LOG="/local/kube_start.log"
echo "executing kube-start" > ${LOG}
PROJ_DIR="$(ls /proj/ | tail -1)"
KUBE_DIR="/proj/${PROJ_DIR}/kube-config"
KUBE_JOIN=${KUBE_DIR}/kube-join.sh
mkdir ${KUBE_DIR}
echo "Made proj directory" > ${LOG}
echo "#!/bin/bash" > ${KUBE_JOIN}
echo "Created kube join file" > ${LOG}
chmod +x ${KUBE_JOIN}

export KUBECONFIG=/local/kubeconfig
echo "Exported KUBECONFIG" > ${LOG}
sudo kubeadm init --pod-network-cidr=10.244.0.0/16 | tail -2 >> ${KUBE_JOIN}
echo "Finished kubeadm init" > ${LOG}
sudo cp -i /etc/kubernetes/admin.conf /local/kubeconfig
sudo chmod 777 /local/kubeconfig
#sudo chown $(id -u):$(id -g) /local/kubeconfig
kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
echo "applied flannel" > ${LOG}

